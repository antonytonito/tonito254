@extends('layouts.main')
@section('contents')
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>


<main class="app-content">

	@include('partials.success')
	@include('partials.errors')

	<div class="container">

		<div class="row app-tile">
			<section class="col-md-10">
	        <div class="wizard">
	            <div class="wizard-inner">
	                <div class="connecting-line"></div>
	                <ul class="nav nav-tabs" role="tablist">

	                    <li role="presentation" class="active">
	                        <a href="#step1" data-toggle="tab" aria-controls="step1" role="tab" title="Step 1">
	                            <span class="round-tab">
	                                <i class="glyphicon glyphicon-folder-open"></i>
	                            </span>
	                        </a>
	                    </li>

	                    <li role="presentation" class="disabled">
	                        <a href="#step2" data-toggle="tab" aria-controls="step2" role="tab" title="Step 2">
	                            <span class="round-tab">
	                                <i class="glyphicon glyphicon-pencil"></i>
	                            </span>
	                        </a>
	                    </li>

	                </ul>
	            </div>

	            <form role="form" method="post" action="{{route('user.store')}}" enctype="multipart/form-data">
								@csrf
	                <div class="tab-content">
	                    <div class="tab-pane active" role="tabpanel" id="step1">
												<div class="container">
													<div class="col-md-4">
														<h3>User info</h3>

														<div class="form-group">
															<label class="control-label">Name</label>
															<input name="name" class="form-control" type="text" placeholder="Name" autofocus>
														</div>
														<div class="form-group">
															<label class="control-label">Email</label>
															<input name="email" class="form-control" type="text" placeholder="Email" autofocus>
														</div>

														<div class="form-group">
															<label class="control-label">Passowrd</label>
															<input name="password" class="form-control" type="password" placeholder="Name" autofocus>
														</div>


													<div class="form-group">
														<label class="control-label"> Confirm Passowrd</label>
														<input name="password_confirmation" class="form-control" type="password" placeholder="Name" autofocus>
													</div>

													</div>
													<div class="col-md-4">

																									<div class="app-sidebar__user">
																											 <img class="app-sidebar__user-avatar" src="{{ URL::to('/') }}/thumbnail/user.png" alt="User Image" style="height:6em">
																									 </div>
																									 <div class="form-group">
														 					               <p>select Image</p>
																										 <input type="file" name="filename" class="form-control">

														 					            </div>



													</div>

												</div>


	                        <ul class="list-inline pull-right">
	                            <li><button type="button" class="btn btn-primary next-step">Save and continue</button></li>
	                        </ul>
	                    </div>



	            <div class="tab-pane" role="tabpanel" id="step2">
												<div class="container">
										<div class="col-md-4">
											<h3>Bio</h3>

											 <div class="form-group">
												 <label class="control-label">Date of Birth</label>

                        <input name="date" class="form-control" id="demoDate2" type="text" placeholder="Select Date">
											 </div>


											 <div class="form-group">
												 <label class="control-label">Phone</label>
												 <input name="phone" class="form-control" type="text" placeholder="phone" autofocus>
											 </div>

											 <div class="form-group">
																 <label for="exampleSelect1">Gender</label>
																 <select name="sex" name="role" class="form-control">
																	 <option value="0">Male</option>
																	 <option value="1">Female</option>

																 </select>
												</div>


											 <div class="form-group">
																 <label for="exampleSelect1">User Role</label>
																 <select name="role" class="form-control">
																	 <option value="1">Normal user</option>
																	 <option value="2">Admin</option>

																 </select>
												</div>


										</div>

										<div class="col-md-6 container">
											<div class="form-group">
												<label for="">Bio(brief intro)</label>
											<textarea name="bioInfo" class="form-control" name="name" rows="4" cols="2"></textarea>
											</div>
										</div>

												</div>

													<ul class="list-inline pull-right">

 														 <li><button type="submit" class="btn btn-primary btn-info-full next-step">Create User</button></li>
 												 </ul>
	                    </div>


	                    <div class="clearfix"></div>
	                </div>
	            </form>
	        </div>
</main>
<script src="{{asset('js/wizard.js')}}"></script>

@endsection
