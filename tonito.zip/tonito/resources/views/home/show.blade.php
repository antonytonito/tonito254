@extends('layouts.main')
@section('contents')
<main class="app-content">
<div class="app-title">
        <div>
          <h1><i class="fa fa-th-list"></i> View User</h1>

        </div>

  </div>
      @include('partials.success')
      @include('partials.errors')

      @foreach($users as $user)
      @endforeach
      <div class="clearfix"></div>

      <div class="col-md-12">
        <div class="tile">

          <div class="container">
            <div class="row">
              <div class="col-md-5">
               <div class="col-md-2 col-md-offset-5">
                 <div class="app-sidebar__user"><img class="app-sidebar__user-avatar" src="{{ URL::to('/') }}/thumbnail/{{$user->avator}}" alt="User Image" style="height:10em; margin-top:60px;margin-left:40px">
                </div>
               </div>

              </div>

              <div class="col-md-6">

                <h1> {{$user->name}}</h1>

                   <br>
                   <br>
                <h5> <strong>Age:</strong>{{$user->age}}</h5>
                 <br>
                <h5><b>Phone:</b> {{$user->phone}}</h5>
                  <br>
                <h5><b>Email:</b> {{$user->email}}</h5>
                   <br>
                <h5><b>Gender:</b> {{$user->sex}}</h5>
                 <br>
                <h5><b>Bio:</b> {{$user->bio_info}}</h5>
                <hr>
                <a href="/manage/users">
                <button class="btn btn-success">Back</button>
                </a>
                <a href="{{url('/user/' .$user->id)}}/edit">
                <button class="btn btn-success">Edit</button>
                </a>
              </div>

            </div>



          </div>

        </div>
      </div>

</main>

@endsection
