@extends('layouts.main')
@section('contents')
<main class="app-content">
<div class="app-title">
        <div>
          <h1><i class="fa fa-th-list"></i> Registered Users</h1>
         
        </div>
        <ul class="app-breadcrumb breadcrumb">
         <button class="btn btn-success">New User</button>
        </ul>
      </div>
      @include('partials.success')
      @include('partials.errors')

         @if(session()->has('register'))
            <div class="alert alert-warning alert-dismissible" role="alert">
            <strong>
            {!! session()->get('register') !!}
            </strong>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
            </div>
            @endif

      <div class="clearfix"></div>
      
      <div class="col-md-10">
        <div class="tile">
        <form method="POST" class="login-form" action="{{route('user.store')}}">
          @csrf
          <div class="form-group">
            <label class="control-label">Name</label>
            <input name="name" class="form-control" type="text" placeholder="Name" autofocus>
          </div>
          <div class="form-group">
            <label class="control-label">Email</label>
            <input name="email" class="form-control" type="text" placeholder="Email" autofocus>
          </div>
          <div class="form-group">
            <label class="control-label">Age</label>
            <input name="age" class="form-control" type="text" placeholder="Age" autofocus>
          </div>
          <div class="form-group">
                    <label for="exampleSelect1">Sex</label>
                    <select name="sex" class="form-control" id="exampleSelect1">
                      <option>Male</option>
                      <option>Female</option>
                    
                    </select>
           </div>
           <div class="form-group">
              <label for="">Date of Birth</label>
              <input name="date" class="form-control" id="demoDate" type="text" placeholder="Select Date">
            </div>
          <div class="form-group">
            <label class="control-label">Password</label>
            <input name="password" class="form-control" type="password" placeholder="Password">
          </div>
          <div class="form-group">
            <label class="control-label"> Confirm Password</label>
            <input name="password_confirmation" class="form-control" type="password" placeholder="Password">
          </div>
         
          <div class="form-group btn-container">
          <input type="submit" value="Create" class="btn btn-primary btn-block">
            
          </div>
        </form>
         
        </div>
      </div>

</main>

@endsection