@extends('layouts.main')
@section('contents')


<main class="app-content">
<div class="app-title">
        <div>
          <h1><i class="fa fa-th-list"></i> Registered Users</h1>

        </div>
        <ul class="app-breadcrumb breadcrumb">
          <a href="{{route('user.create')}}">
          <button class="btn btn-success">New User</button>
          </a>

        </ul>
      </div>
      @include('partials.success')
      @include('partials.errors')

      <div class="clearfix"></div>

      <div class="col-md-12">
        <div class="tile">
          <h3 class="tile-title">Total users: {{$users->count()}}</h3>
          <div class="tile-body">
              <table class="table table-hover " id="sampleTable">
              <thead>
                <tr>
                  <th>Member</th>

                  <th>email</th>
                  <th>Phone</th>
                  <th>Age</th>
                  <th>Gender</th>
                  <td>Action</td>
                </tr>
              </thead>
              <tbody>

              @foreach($users as $user)

              <tr>
                <td>
                <div class="app-sidebar__user"><img class="app-sidebar__user-avatar" src="{{ URL::to('/') }}/thumbnail/{{$user->avator}}" alt="User Image">
                  <span class="text-primary">{{$user->name}}</span>
                 <div>
                 </td>

                  <td>{{$user->email}}</td>
                  <td>{{$user->phone}}</td>
                  <td>{{$user->age}}</td>
                  <td>
                    @if($user->sex == 0)
                    <span>Female</span>
                    @else
                    <span>Male</span>
                    @endif

                  </td>


                  <td>
                  <a href="{{url('user/' . $user->id)}}">
                    <i data-toggle="tooltip" title="View User"class="fa fa-ellipsis-v" aria-hidden="true"></i>

                  </a>
                  </td>
                </tr>
              @endforeach



                </tbody>
              </table>
            </div>



        </div>
      </div>

</main>



@endsection
