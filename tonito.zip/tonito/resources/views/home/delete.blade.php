@extends('layouts.main')
@section('contents')
<main class="app-content">
<div class="app-title">
        <div>
          <h1><i class="fa fa-th-list"></i> Manage Users</h1>

        </div>
        <ul class="app-breadcrumb breadcrumb">
          <a href="{{route('user.create')}}">
          <button class="btn btn-success">New User</button>
          </a>

        </ul>
      </div>
      @include('partials.success')
      @include('partials.errors')

      <div class="clearfix"></div>

      <div class="col-md-12">
        <div class="tile">
        @if(!auth()->user()->role == 1)
          <h3 class="tile-title">Total users: {{$users->count()}}</h3>
        @endif
          <div class="table-responsive">
            <table class="table">
              <thead>
                <tr>
                   <th>Member</th>

                   <th>email</th>
                   <th>phone</th>
                   <th>Role</th>
                   <th>Activated</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
            @if(auth()->user()->role == 1)
            <tr>
              <td>
              <div class="app-sidebar__user"><img class="app-sidebar__user-avatar" src="{{auth()->user()->gravatar}}" alt="User Image">
                  <span class="text-success">{{auth()->user()->name}}</span>
               <div>
              </td>

                  <td>{{auth()->user()->email}}</td>
                  <td>{{auth()->user()->phone}}</td>

                  <td>


                    <span class="badge badge-info">User</span>

                  </td>
                  <td>
                      <a href="{{url('/toggle/' .auth()->user()->id)}}">

                      @if(auth()->user()->email_verified_at != null)
                        <button data-toggle="tooltip" title="Deactivate User"  class="btn btn-success">True</button>
                        @else
                        <button data-toggle="tooltip" title="Activate User"  class="btn btn-danger">False</button>
                        @endif

                      </a>



                  <td>
                    <a href="{{url('/user/' .auth()->user()->id)}}/edit">
                    <button data-toggle="tooltip" title="Edit User"  class="btn"> <i class="fa fa-edit"></i> </button>
                    </a>
                  <a href="{{url('/user/' .auth()->user()->id)}}">
                    <button data-toggle="tooltip" title="View User"  class="btn"> <i class="fa fa-eye"></i> </button>
                  </a>

                   <a
                   onclick="event.preventDefault();
                   document.getElementById('delete-form').submit();"
                   >
                   <button data-toggle="tooltip" title="Delete User"  class="btn"> <i class="fa fa-trash"></i> </button>
                   </a>
                   <a href="{{url('/password/reset/' .auth()->user()->id)}}">
                    <button data-toggle="tooltip" title="Reset Password"  class="btn"> <i class="fa fa-eye"></i> </button>
                  </a>

                   <form id="delete-form" action="{{url('/user/' .auth()->user()->id)}}" method="POST" style="display:none">
                     @csrf
                     <input type="hidden" value="DELETE" name="_method">
                     <input type="submit" value="delete " >
                   </form>

                  </td>
                </tr>
                @else

              @foreach($users as $user)
              <tr>
                <td>
                <div class="app-sidebar__user"><img class="app-sidebar__user-avatar" src="{{$user->gravatar}}" alt="User Image">
                <span class="text-success">{{$user->name}}</span>
                <div>


                </td>

                  <td>{{$user->email}}</td>
                  <td>{{$user->phone}}</td>

                  <td>
                  @if($user->role == 1)

                      <span data-toggle="tooltip" title="Make an Admin" class="badge badge-info">User</span>
                  @else
                    <span data-toggle="tooltip" title="Make a normal user" class="badge badge-info">Admin</span>
                  @endif
                  </td>
                  <td>
                      <a href="url{{('/toggle/' .$user->id)}}">

                      @if($user->email_verified_at != null)

                          <span data-toggle="tooltip" title="Deactivate User"  class="badge badge-danger">Activated</span>
                        @else
                          <span data-toggle="tooltip" title="Activate User"  class="badge badge-success">Inactive</span>
                        @endif

                      </a>



                  <td>
                    <a href="{{url('/user/' .$user->id)}}/edit">
                    <button data-toggle="tooltip" title="Edit User"  class="btn"> <i class="fa fa-edit"></i> </button>
                    </a>
                  <a href="{{url('/user/' .$user->id)}}">
                    <button data-toggle="tooltip" title="View User"  class="btn"> <i class="fa fa-eye"></i> </button>
                  </a>

                   <a
                   onclick="event.preventDefault();
                   document.getElementById('delete-form').submit();"
                   >
                   <button data-toggle="tooltip" title="Delete User"  class="btn"> <i class="fa fa-trash"></i> </button>
                   </a>
                   <a href="{{url('/password/reset/' .$user->id)}}">
                    <button data-toggle="tooltip" title="Reset Password"  class="btn"> <i class="fa fa-eye"></i> </button>
                  </a>

                   <form id="delete-form" action="{{url('/user/' .$user->id)}}" method="POST" style="display:none">
                     @csrf
                     <input type="hidden" value="DELETE" name="_method">
                     <input type="submit" value="delete " >
                   </form>

                  </td>
                </tr>
              @endforeach
              @endif



              </tbody>
            </table>
          </div>
        </div>
      </div>

</main>

@endsection
