<?php $__env->startSection('contents'); ?>
<main class="app-content">
<div class="app-title">
        <div>
          <h1><i class="fa fa-th-list"></i> Edit User</h1>

        </div>

      </div>
      <?php echo $__env->make('partials.success', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <?php echo $__env->make('partials.errors', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

      <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

      <div class="clearfix"></div>

      <div class="col-md-10">
        <div class="tile">
        <form method="POST" class="login-form" action="/user/<?php echo e($user->id); ?>">
          <?php echo csrf_field(); ?>
          <input type="hidden" name="_method" value="put">
          <div class="form-group">
            <label class="control-label">Name</label>
            <input value="<?php echo e($user->name); ?>" name="name" class="form-control" type="text" placeholder="Name" autofocus>
          </div>
          <div class="form-group">
            <label class="control-label">Email</label>
            <input value="<?php echo e($user->email); ?>" name="email" class="form-control" type="text" placeholder="Email" autofocus>
          </div>
          <div class="form-group">
            <label class="control-label">Age</label>
            <input value="<?php echo e($user->age); ?>" name="age" class="form-control" type="text" placeholder="Age" autofocus>
          </div>
          <div class="form-group">
                    <label for="exampleSelect1">Sex</label>
                    <select selected="<?php echo e($user->sex); ?>" name="sex" class="form-control" id="exampleSelect1">
                      <option>Male</option>
                      <option>Female</option>

                    </select>
           </div>
           <div class="form-group">
              <label for="">Date of Birth</label>
              <input value="<?php echo e($user->dob); ?>" name="date" class="form-control" id="demoDate" type="text" placeholder="Select Date">
            </div>



          <div class="form-group btn-container">
          <input type="submit" value="Update" class="btn btn-primary btn-block">

          </div>
        </form>

        <div class="app-sidebar__user">
             <?php if($user->avator == null): ?>
             <img class="app-sidebar__user-avatar" src="<?php echo e($user->gravatar); ?>" alt="User Image">
             <?php else: ?>
             <img class="app-sidebar__user-avatar" src="<?php echo e(URL::to('/')); ?>/thumbnail/<?php echo e($user->avator); ?>" alt="User Image">
             <?php endif; ?>

           </div>
           <div>
              <p>Change Image</p>
                 <form method="post" action="<?php echo e(route('change-image')); ?>" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                          <div class="col-md-4"></div>
                          <div class="form-group col-md-4">
                          <input type="file" name="filename" class="form-control">
                          </div>
                        </div>
                        <div class="row">
                          <div class="col-md-4"></div>
                          <div class="form-group col-md-4">
                          <button type="submit" class="btn btn-success" style="margin-top:10px">Upload Image</button>
                          </div>
                        </div>
                  </form>
           </div>

        </div>
      </div>

</main>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>