<?php $__env->startSection('contents'); ?>
<main class="app-content">
<div class="app-title">
        <div>
          <h1><i class="fa fa-th-list"></i> Manage Users</h1>

        </div>
        <ul class="app-breadcrumb breadcrumb">
          <a href="<?php echo e(route('user.create')); ?>">
          <button class="btn btn-success">New User</button>
          </a>

        </ul>
      </div>
      <?php echo $__env->make('partials.success', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <?php echo $__env->make('partials.errors', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

      <div class="clearfix"></div>

      <div class="col-md-12">
        <div class="tile">
        <?php if(!auth()->user()->role == 1): ?>
          <h3 class="tile-title">Total users: <?php echo e($users->count()); ?></h3>
        <?php endif; ?>
          <div class="table-responsive">
            <table class="table">
              <thead>
                <tr>
                   <th>Member</th>

                   <th>email</th>
                   <th>phone</th>
                   <th>Role</th>
                   <th>Activated</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
            <?php if(auth()->user()->role == 1): ?>
            <tr>
              <td>
              <div class="app-sidebar__user"><img class="app-sidebar__user-avatar" src="<?php echo e(auth()->user()->gravatar); ?>" alt="User Image">
                  <span class="text-success"><?php echo e(auth()->user()->name); ?></span>
               <div>
              </td>

                  <td><?php echo e(auth()->user()->email); ?></td>
                  <td><?php echo e(auth()->user()->phone); ?></td>

                  <td>


                    <span class="badge badge-info">User</span>

                  </td>
                  <td>
                      <a href="<?php echo e(url('/toggle/' .auth()->user()->id)); ?>">

                      <?php if(auth()->user()->email_verified_at != null): ?>
                        <button data-toggle="tooltip" title="Deactivate User"  class="btn btn-success">True</button>
                        <?php else: ?>
                        <button data-toggle="tooltip" title="Activate User"  class="btn btn-danger">False</button>
                        <?php endif; ?>

                      </a>



                  <td>
                    <a href="<?php echo e(url('/user/' .auth()->user()->id)); ?>/edit">
                    <button data-toggle="tooltip" title="Edit User"  class="btn"> <i class="fa fa-edit"></i> </button>
                    </a>
                  <a href="<?php echo e(url('/user/' .auth()->user()->id)); ?>">
                    <button data-toggle="tooltip" title="View User"  class="btn"> <i class="fa fa-eye"></i> </button>
                  </a>

                   <a
                   onclick="event.preventDefault();
                   document.getElementById('delete-form').submit();"
                   >
                   <button data-toggle="tooltip" title="Delete User"  class="btn"> <i class="fa fa-trash"></i> </button>
                   </a>
                   <a href="<?php echo e(url('/password/reset/' .auth()->user()->id)); ?>">
                    <button data-toggle="tooltip" title="Reset Password"  class="btn"> <i class="fa fa-eye"></i> </button>
                  </a>

                   <form id="delete-form" action="<?php echo e(url('/user/' .auth()->user()->id)); ?>" method="POST" style="display:none">
                     <?php echo csrf_field(); ?>
                     <input type="hidden" value="DELETE" name="_method">
                     <input type="submit" value="delete " >
                   </form>

                  </td>
                </tr>
                <?php else: ?>

              <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td>
                <div class="app-sidebar__user"><img class="app-sidebar__user-avatar" src="<?php echo e($user->gravatar); ?>" alt="User Image">
                <span class="text-success"><?php echo e($user->name); ?></span>
                <div>


                </td>

                  <td><?php echo e($user->email); ?></td>
                  <td><?php echo e($user->phone); ?></td>

                  <td>
                  <?php if($user->role == 1): ?>

                      <span data-toggle="tooltip" title="Make an Admin" class="badge badge-info">User</span>
                  <?php else: ?>
                    <span data-toggle="tooltip" title="Make a normal user" class="badge badge-info">Admin</span>
                  <?php endif; ?>
                  </td>
                  <td>
                      <a href="url<?php echo e(('/toggle/' .$user->id)); ?>">

                      <?php if($user->email_verified_at != null): ?>

                          <span data-toggle="tooltip" title="Deactivate User"  class="badge badge-danger">Activated</span>
                        <?php else: ?>
                          <span data-toggle="tooltip" title="Activate User"  class="badge badge-success">Inactive</span>
                        <?php endif; ?>

                      </a>



                  <td>
                    <a href="<?php echo e(url('/user/' .$user->id)); ?>/edit">
                    <button data-toggle="tooltip" title="Edit User"  class="btn"> <i class="fa fa-edit"></i> </button>
                    </a>
                  <a href="<?php echo e(url('/user/' .$user->id)); ?>">
                    <button data-toggle="tooltip" title="View User"  class="btn"> <i class="fa fa-eye"></i> </button>
                  </a>

                   <a
                   onclick="event.preventDefault();
                   document.getElementById('delete-form').submit();"
                   >
                   <button data-toggle="tooltip" title="Delete User"  class="btn"> <i class="fa fa-trash"></i> </button>
                   </a>
                   <a href="<?php echo e(url('/password/reset/' .$user->id)); ?>">
                    <button data-toggle="tooltip" title="Reset Password"  class="btn"> <i class="fa fa-eye"></i> </button>
                  </a>

                   <form id="delete-form" action="<?php echo e(url('/user/' .$user->id)); ?>" method="POST" style="display:none">
                     <?php echo csrf_field(); ?>
                     <input type="hidden" value="DELETE" name="_method">
                     <input type="submit" value="delete " >
                   </form>

                  </td>
                </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <?php endif; ?>



              </tbody>
            </table>
          </div>
        </div>
      </div>

</main>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>