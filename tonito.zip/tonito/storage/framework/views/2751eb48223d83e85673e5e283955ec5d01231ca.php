<?php $__env->startSection('contents'); ?>
<main class="app-content">
<div class="app-title">
        <div>
          <h1><i class="fa fa-th-list"></i> View User</h1>

        </div>

  </div>
      <?php echo $__env->make('partials.success', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <?php echo $__env->make('partials.errors', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

      <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <div class="clearfix"></div>

      <div class="col-md-12">
        <div class="tile">

          <div class="container">
            <div class="row">
              <div class="col-md-5">
               <div class="col-md-2 col-md-offset-5">
                 <div class="app-sidebar__user"><img class="app-sidebar__user-avatar" src="<?php echo e($user->gravatar); ?>" alt="User Image" style="height:10em; margin-top:60px;margin-left:40px">
                </div>
               </div>

              </div>

              <div class="col-md-6">

                <h1> <?php echo e($user->name); ?></h1>

                   <br>
                   <br>
                <h5> <strong>Age:</strong><?php echo e($user->age); ?></h5>
                 <br>
                <h5><b>Phone:</b> <?php echo e($user->phone); ?></h5>
                  <br>
                <h5><b>Email:</b> <?php echo e($user->email); ?></h5>
                   <br>
                <h5><b>Gender:</b> <?php echo e($user->sex); ?></h5>
                 <br>
                <h5><b>Bio:</b> <?php echo e($user->bio_info); ?></h5>
                <hr>
                <a href="/manage/users">
                <button class="btn btn-success">Back</button>
                </a>
                <a href="/user/<?php echo e($user->id); ?>/edit">
                <button class="btn btn-success">Edit</button>
                </a>
              </div>

            </div>



          </div>

        </div>
      </div>

</main>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>