<?php $__env->startSection('contents'); ?>


<main class="app-content">
<div class="app-title">
        <div>
          <h1><i class="fa fa-th-list"></i> Registered Users</h1>

        </div>
        <ul class="app-breadcrumb breadcrumb">
          <a href="<?php echo e(route('user.create')); ?>">
          <button class="btn btn-success">New User</button>
          </a>

        </ul>
      </div>
      <?php echo $__env->make('partials.success', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <?php echo $__env->make('partials.errors', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

      <div class="clearfix"></div>

      <div class="col-md-12">
        <div class="tile">
          <h3 class="tile-title">Total users: <?php echo e($users->count()); ?></h3>
          <div class="tile-body">
              <table class="table table-hover " id="sampleTable">
              <thead>
                <tr>
                  <th>Member</th>

                  <th>email</th>
                  <th>Phone</th>
                  <th>Age</th>
                  <th>Gender</th>
                  <td>Action</td>
                </tr>
              </thead>
              <tbody>

              <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

              <tr>
                <td>
                <div class="app-sidebar__user"><img class="app-sidebar__user-avatar" src="<?php echo e($user->gravatar); ?>" alt="User Image">
                  <span class="text-primary"><?php echo e($user->name); ?></span>
                 <div>
                 </td>

                  <td><?php echo e($user->email); ?></td>
                  <td><?php echo e($user->phone); ?></td>
                  <td><?php echo e($user->age); ?></td>
                  <td>
                    <?php if($user->sex == 0): ?>
                    <span>Female</span>
                    <?php else: ?>
                    <span>Male</span>
                    <?php endif; ?>

                  </td>


                  <td>
                  <a href="/user/<?php echo e($user->id); ?>">
                    <i data-toggle="tooltip" title="View User"class="fa fa-ellipsis-v" aria-hidden="true"></i>

                  </a>
                  </td>
                </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                </tbody>
              </table>
            </div>



        </div>
      </div>

</main>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>