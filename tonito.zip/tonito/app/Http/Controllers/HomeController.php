<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use Auth;
class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
         if(Auth::user()->role ==2){
           $users=User::all();
           return view('home.index',['users'=>$users]);

         }else{
           if (Auth::user()->sex ==0) {
             $users=User::where('sex',0)->get();
             return view('home.index',['users'=>$users]);
           }else{
             $users=User::where('sex',1)->get();
             return view('home.index',['users'=>$users]);
           }
         }




    }
}
