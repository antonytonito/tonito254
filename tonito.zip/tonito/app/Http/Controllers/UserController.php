<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use Hash;
use Carbon\Carbon;
use Image;
use Auth;

class UserController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('home.create');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('home.create2');

    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {

     //validate
      $request->validate([
        'name' => 'required',
        'email' => 'required',
        'sex'=> 'required',
        'date' => 'required',
        'phone' => 'required',
        'role' => 'required',
        'password' => 'required'
      ]);
      //Upoload selected image
      $originalImage= $request->file('filename');
      $thumbnailImage = Image::make($originalImage);
      $thumbnailPath = public_path().'/thumbnail/';
      $originalPath = public_path().'/images/';
      $thumbnailImage->save($originalPath.time().$originalImage->getClientOriginalName());
      $thumbnailImage->resize(150,150);
      $thumbnailImage->save($thumbnailPath.time().$originalImage->getClientOriginalName());


      $imageName=$thumbnailImage->basename;

       //dd($imageName);




        $user= User::create([
            'name' => $request['name'],
            'email' => $request['email'],
            'sex' => $request->input('sex'),
            'dob' =>$request['date'],
            'phone'=>$request->input('phone'),
            'role' => $request['role'],
            'avator' =>$imageName,
            'bio_info'=>$request['bioInfo'],
            'password' => Hash::make($request['password']),
        ]);

        if($user){
            return redirect('/home')->with('success','User Registered');
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     *
     */

    public function manageUser(){

            $users=User::all();
         return view('home.delete',['users'=>$users]);
     }
    public function show($id)
    {
        $user=User::where('id',$id)->get();
        return view('home.show',['users'=>$user]);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $user=User::where('id',$id)->get();

        return view('home.edit2',['users'=>$user])->with('success','Edit the specified user');
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {

      //validate
       $request->validate([
         'name' => 'required',
         'email' => 'required',
         // 'sex'=> 'required',
         // 'date' => 'required',
         'phone' => 'required',
         // 'role' => 'required',

       ]);

       //Upoload selected image
       $originalImage= $request->file('filename');
       $thumbnailImage = Image::make($originalImage);
       $thumbnailPath = public_path().'/thumbnail/';
       $originalPath = public_path().'/images/';
       $thumbnailImage->save($originalPath.time().$originalImage->getClientOriginalName());
       $thumbnailImage->resize(150,150);
       $thumbnailImage->save($thumbnailPath.time().$originalImage->getClientOriginalName());
       $imageName=$thumbnailImage->basename;

        //update
        $updateUser=User::where('id',$id)->update([
          'name' => $request['name'],
          'email' => $request['email'],
          // // 'sex' => $request->input('sex'),
          // 'dob' =>$request['date'],
          'phone'=>$request->input('phone'),
          // 'role' => $request['role'],
          'avator' =>$imageName,
          'bio_info'=>$request['bioInfo'],
          // 'password' => Hash::make($request['password']),
        ]);

        if($updateUser){
            return redirect()->route('home')->with('success','user updated successfully');
        }else{
            return back()->withInput()->with('errors','User could not update');
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $deleteUser=User::where('id',$id)->delete();

        if($deleteUser){
            return back()->with('success','User Deleted');
        }
    }

    public function toggleActivate($id){
     $value=User::where('id',$id)->value('email_verified_at');
     if($value == null){
        $toggle=User::where('id',$id)->update(['email_verified_at'=>Carbon::now()]);
     }else{
        $toggle=User::where('id',$id)->update(['email_verified_at'=>null]);
     }

     return back();

    }

    public function changeImage(Request $request){
        $originalImage= $request->file('filename');
        $thumbnailImage = Image::make($originalImage);
        $thumbnailPath = public_path().'/thumbnail/';
        $originalPath = public_path().'/images/';
        $thumbnailImage->save($originalPath.time().$originalImage->getClientOriginalName());
        $thumbnailImage->resize(150,150);
        $thumbnailImage->save($thumbnailPath.time().$originalImage->getClientOriginalName());


        $imageName=$thumbnailImage->basename;

        //Update user table
        $update=User::where('id',Auth::user()->id)->update(['avator'=>$imageName]);
        if($update){
            return back()->with('success','Image updated Successfully');
        }
    }
}
