<?php

namespace App;

use Illuminate\Notifications\Notifiable;
use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Carbon\Carbon;

class User extends Authenticatable
{
    use Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'name', 'email','sex','dob', 'password','phone','bio_info',
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token',
    ];

    public function getGravatarAttribute()
    {
        $hash = md5(strtolower(trim($this->attributes['email']))).'?s=40d';
        return "http://www.gravatar.com/avatar/$hash";
    }

    public function getAgeAttribute()
    {
      $dateOfBirth=$this->attributes['dob'];
      $years = Carbon::parse($dateOfBirth)->age;

      return $years;
    }
}
