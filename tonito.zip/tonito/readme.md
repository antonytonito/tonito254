# Installation
## Setup
Clones the repository
```
git clone https://github.com/gathuku/victor.git
```
After cloning run
```
composer install
```
This will install all the project dependancies

##  migration
To run migration, run the command
```
php artisan migrate
```

## Dummy Data
```
php artisan db:seed --class=UserTableSeeder
```
## Test Credentials
```
Email: johndoe@gmail.com
Password: password
```
## Mail configuration
For you to send email create an account with (sendgrid)[https://sendgrid.com/?opt=1]
Then update mail configuration in env file
```
MAIL_DRIVER=smtp
MAIL_HOST=smtp.sendgrid.net
MAIL_PORT=587
MAIL_USERNAME=mosesgathuku95@gmail.com
MAIL_PASSWORD=gathuku9%5
MAIL_ENCRYPTION=tls
```
