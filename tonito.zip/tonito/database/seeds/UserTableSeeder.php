<?php

use Illuminate\Database\Seeder;

use Illuminate\Support\Facades\DB;

use Faker\Factory as Faker;

class UserTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
         DB::table('users')->delete();
        $faker=Faker::create();
      //  $gender = $faker->randomElement(['0','1']);
        foreach(range(1,10) as $index){
            DB::table('users')->insert([
                'name' => $faker->name,
                'email' => $faker->email,

                'sex' =>$faker->randomElement(['0', '1']),
                'phone'=>$faker->e164PhoneNumber,
                'bio_info'=>null,
                'dob' =>$faker->date($format = 'Y-m-d', $max = 'now'),
                'role'=>$faker->randomElement(['1', '2']),
                'avator'=>'',
	              'password' => bcrypt('secret'),
            ]);
        }
    }
}
